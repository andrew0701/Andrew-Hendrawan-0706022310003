﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SayaPinginMati
{
    public partial class Form1 : Form
    {
        DataTable dt = new DataTable();
        List<Team> pusingakuya = new List<Team>();
        List<string> countrylist = new List<string>();
        List<string> teamlist = new List<string>();
        List<string> teamlistpilih = new List<string>();
        string[] posisiorang = { "GK", "DF", "MF", "FW" };
        int Country = 0;
        int Team = 0;
        public Form1()
        {
            InitializeComponent();

            string[] pusingmautaruhapa = { "England", "England", "Spain" };
            string[] pusingmautaruhapajuga = { "Manchester", "Liverpool", "Madrid" };
            string[] pusingmautaruhapaterakhir = { "Manchester United", "Liverpool", "Real Madrid" };
            string[] nyerahsy = { "Marcus Rashford", "leo Paul", "Bruno Fernandes", "Paul Pogba", "Harry Maguire", "David de Gea", "Luke Shaw", "Aaron Wan-Bissaka", "Mason Greenwood", "Fred", "Edinson Cavani", "Raphael Varane" };
            string[] nyerahsya = { "Jamie Vardy", "Andrew Benze", "Andrew Robertson", "Harry Maguire", "James Ward-Prowse", "Aaron Wan-Bissaka", "Jesse Lingard", "Harvey Barnes", "John Stones", "Ben White", "Emile Smith Rowe", "Connor Gallagher" };
            string[] nyerahsyaa = { "Karim Benzema", "Vinícius Júnior", "Luka Modrić", "Thibaut Courtois", "Sergio Ramos","lelelel", "Toni Kroos", "Casemiro", "Ferland Mendy", "Marco Asensio", "Éder Militão", "Rodrygo" };
            string[] fh = { "1", "2", "3", "6", "9", "10", "13", "15", "18", "19", "21", "22" };
            string[] yawslah = { "GK", "DF", "DF", "DF", "MF", "MF", "MF", "MF", "MF", "FW", "FW", "FW" };

            for (int i = 0; i < 3; i++)
            {
                Team team = new Team();
                team.teamCountry = pusingmautaruhapa[i];
                team.teamCity = pusingmautaruhapajuga[i];
                team.teamName = pusingmautaruhapaterakhir[i];
                List<Player> playerlist = new List<Player>();
                for (int j = 0; j < 12; j++)
                {
                    Player player = new Player();
                    if (i == 0)
                    {
                        player.playerName = nyerahsy[j];
                    }
                    else if (i == 1)
                    {
                        player.playerName = nyerahsya[j];
                    }
                    else
                    {
                        player.playerName = nyerahsyaa[j];
                    }
                    player.playerNum = fh[j];
                    player.playerPos = yawslah[j];
                    playerlist.Add(player);
                }
                team.Players = playerlist;
                pusingakuya.Add(team);
            }
            dt.Columns.Add("Country");
            dt.Columns.Add("City");
            dt.Columns.Add("Team");
            dt.Columns.Add("Playerss");
            dt.Columns.Add("Number");
            dt.Columns.Add("Position");
            dt.Rows.Add("England", "Manchester", "Manchester United", "David de Gea", "1", "GK");
            dt.Rows.Add("England", "Manchester", "Manchester United", "Harry Maguire", "5", "DF");
            dt.Rows.Add("England", "Manchester", "Manchester United", "Marcus Rashford", "10", "FW");
            dt.Rows.Add("England", "Manchester", "Manchester United", "Luke Shaw", "23", "DF");
            dt.Rows.Add("England", "Manchester", "Manchester United", "Jadon Sancho", "25", "FW");
            dt.Rows.Add("England", "Manchester", "Manchester United", "Mason Greenwood", "11", "FW");
            dt.Rows.Add("England", "Manchester", "Manchester United", "Scott McTominay", "39", "MF");
            dt.Rows.Add("England", "Manchester", "Manchester United", "Axel Tuanzebe", "38", "DF");
            dt.Rows.Add("England", "Manchester", "Manchester United", "Brandon Williams", "33", "DF");
            dt.Rows.Add("England", "Manchester", "Manchester United", "Jesse Lingard", "14", "MF");
            dt.Rows.Add("England", "Manchester", "Manchester United", "Dean Henderson", "26", "GK");
            dt.Rows.Add("England", "Liverpool", "Liverpool", "Alisson Becker", "1", "GK");
            dt.Rows.Add("England", "Liverpool", "Liverpool", "Trent Alexander-Arnold", "66", "DF");
            dt.Rows.Add("England", "Liverpool", "Liverpool", "Virgil van Dijk", "4", "DF");
            dt.Rows.Add("England", "Liverpool", "Liverpool", "Joël Matip", "32", "DF");
            dt.Rows.Add("England", "Liverpool", "Liverpool", "Andrew Robertson", "26", "DF");
            dt.Rows.Add("England", "Liverpool", "Liverpool", "Fabinho", "3", "MF");
            dt.Rows.Add("England", "Liverpool", "Liverpool", "Jordan Henderson", "14", "MF");
            dt.Rows.Add("England", "Liverpool", "Liverpool", "Thiago Alcântara", "6", "MF");
            dt.Rows.Add("England", "Liverpool", "Liverpool", "Mohamed Salah", "11", "FW");
            dt.Rows.Add("England", "Liverpool", "Liverpool", "Sadio Mané", "10", "FW");
            dt.Rows.Add("England", "Liverpool", "Liverpool", "Roberto Firmino", "9", "FW");
            dt.Rows.Add("Spain", "Madrid", "Real Madrid", "Karim Benzema", "1", "GK");
            dt.Rows.Add("Spain", "Madrid", "Real Madrid", "Vinícius Júnior", "2", "DF");
            dt.Rows.Add("Spain", "Madrid", "Real Madrid", "Luka Modrić", "3", "DF");
            dt.Rows.Add("Spain", "Madrid", "Real Madrid", "Thibaut Courtois", "4", "DF");
            dt.Rows.Add("Spain", "Madrid", "Real Madrid", "Sergio Ramos", "23", "DF");
            dt.Rows.Add("Spain", "Madrid", "Real Madrid", "Toni Kroos", "14", "MF");
            dt.Rows.Add("Spain", "Madrid", "Real Madrid", "Casemiro", "10", "MF");
            dt.Rows.Add("Spain", "Madrid", "Real Madrid", "Ferland Mendy", "8", "MF");
            dt.Rows.Add("Spain", "Madrid", "Real Madrid", "Eden Hazard", "7", "FW");
            dt.Rows.Add("Spain", "Madrid", "Real Madrid", "Karim Benzema", "9", "FW");
            dt.Rows.Add("Spain", "Madrid", "Real Madrid", "Rodrygo", "20", "FW");
            countrylist.Add("England");
            countrylist.Add("Spain");
            teamlist.Add("England=Manchester United");
            teamlist.Add("England=Liverpool");
            teamlist.Add("Spain=Real Madrid");
            for (int i = 0; i < countrylist.Count; i++)
            {
                negara.Items.Add(countrylist[i]);
            }
        }

        private void comboBox1_SelectionChangeCommitted(object sender, EventArgs e)
        {
            namatimnegara.Items.Clear();
            teamlistpilih.Clear();
            for (int i = 0; i < teamlist.Count; i++)
            {
                if (teamlist[i].Contains(countrylist[negara.SelectedIndex] + "="))
                {
                    string[] namateam = teamlist[i].Split('=');
                    namatimnegara.Items.Add(namateam[1]);
                    teamlistpilih.Add(namateam[1]);
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            bool khkua = false;
            bool hjh = true;

            for (int i = 0; i < countrylist.Count; i++)
            {
                if (bebasajanamanya.Text == countrylist[i])
                {
                    khkua = true;
                    for (int j = 0; j < teamlist.Count; j++)
                    {
                        if (negaranegarayangberada.Text == teamlist[i])
                        {
                            hjh = false;
                        }
                    }
                }
            }

            if (bebasajanamanya.Text != "" && negaranegarayangberada.Text != "" && kotayangtercintah.Text != "")
            {
                if (khkua)
                {
                    MessageBox.Show("sudah ada");
                }
                else
                {
                    teamlist.Add(bebasajanamanya.Text + "=" + negaranegarayangberada.Text);
                    if (hjh)
                    {
                        countrylist.Add(bebasajanamanya.Text);
                    }
                    negara.Items.Clear();
                    bebasajanamanya.Text = "";
                    negaranegarayangberada.Text = "";
                    kotayangtercintah.Text = "";
                    for (int i = 0; i < countrylist.Count; i++)
                    {
                        negara.Items.Add(countrylist[i]);
                    }
                }
            }
            else
            {
                MessageBox.Show("Maaf, ada yang belum di isi");
            }

        }



        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            listboxbesaryangkitabisalihatorang.Items.Clear();

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                if (namatimnegara.Text == dt.Rows[i][2].ToString())
                {
                    listboxbesaryangkitabisalihatorang.Items.Add("("+dt.Rows[i][4].ToString() + ") "+dt.Rows[i][3].ToString()+","+ dt.Rows[i][5].ToString());
                }
            }
        }

        

        private void button1_Click(object sender, EventArgs e)
        {
            string nama = listboxbesaryangkitabisalihatorang.SelectedItem.ToString();
            bool a = false;

            string team = teamlistpilih[namatimnegara.SelectedIndex];

            int hitung = 0;
            for (int i = 0;i < dt.Rows.Count; i++)
            {
                if (team == dt.Rows[i][2].ToString())
                {
                    hitung++;
                }
            }

            if (hitung <= 11)
            {
                a = true;
            }

            if (a)
            {
                MessageBox.Show("tidak bisa dibawah 11");
            }
            else
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    if (nama.Contains(dt.Rows[i][3].ToString()))
                    {
                        dt.Rows[i].Delete();
                    }
                }

                listboxbesaryangkitabisalihatorang.Items.Clear();

                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    if (namatimnegara.Text == dt.Rows[i][2].ToString())
                    {
                        listboxbesaryangkitabisalihatorang.Items.Add("(" + dt.Rows[i][4].ToString() + ") " + dt.Rows[i][3].ToString() + "," + dt.Rows[i][5].ToString());
                    }
                }
            }
        }
        private void button3_Click(object sender, EventArgs e)
        {
            string namaorangnya = namaorangyajelaspastiadamosoknamanyakosonggakkanyaapuun.Text;
            string nomerbajudia = nomerdibelakangbaju.Text;
            string posisinya = posisiorang[posisikitadimana.SelectedIndex];
            if (namaorangnya != "" && nomerbajudia != "" && posisikitadimana.SelectedIndex != -1)
            {
                if (negara.SelectedIndex != -1 && namatimnegara.SelectedIndex != -1)
                {
                    dt.Rows.Add(countrylist[negara.SelectedIndex], teamlistpilih[namatimnegara.SelectedIndex], teamlistpilih[namatimnegara.SelectedIndex], namaorangnya, nomerbajudia, posisinya);

                }
                namaorangyajelaspastiadamosoknamanyakosonggakkanyaapuun.Text = "";
                nomerdibelakangbaju.Text = "";
                posisikitadimana.SelectedIndex = -1;
                listboxbesaryangkitabisalihatorang.Items.Clear();
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    if (namatimnegara.Text == dt.Rows[i][2].ToString())
                    {
                        listboxbesaryangkitabisalihatorang.Items.Add("(" + dt.Rows[i][4].ToString() + ") " + dt.Rows[i][3].ToString() + "," + dt.Rows[i][5].ToString());
                    }
                }
            }
            else
            {
                MessageBox.Show("Maaf, ada yang belum di isi");
            }
        }

        private void ampundah_SelectedIndexChanged(object sender, EventArgs e)
        {
            listboxbesaryangkitabisalihatorang.Items.Clear();

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                if (namatimnegara.Text == dt.Rows[i][2].ToString())
                {
                    listboxbesaryangkitabisalihatorang.Items.Add("(" + dt.Rows[i][4].ToString() + ") " + dt.Rows[i][3].ToString() + "," + dt.Rows[i][5].ToString());
                }
            }
        }
    }
}
